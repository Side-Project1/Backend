package com.project.server.security;

public enum AuthProvider {
    local,
    kakao,
    github,
    naver
}
